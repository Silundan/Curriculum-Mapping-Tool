1. pwd (make sure you are under directory "project/" )
2. npm install
3. node app.js
4. open your browser http://localhost:9000
